package com.tradingpredictor.app;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;

public class MainActivity extends Activity {
  private static final int FILE_CHOOSER = 1001;
  private ValueCallback<Uri[]> uploadMessage;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(11,16,24));
    getWindow().setNavigationBarColor(Color.rgb(11,16,24));
    WebView w = new WebView(this);
    w.setBackgroundColor(Color.rgb(11,16,24));
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
    w.setWebViewClient(new WebViewClient());
    w.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView web, ValueCallback<Uri[]> cb, FileChooserParams params) {
        if (uploadMessage != null) uploadMessage.onReceiveValue(null);
        uploadMessage = cb;
        Intent i = params.createIntent();
        try { startActivityForResult(i, FILE_CHOOSER); }
        catch (Exception e) { uploadMessage = null; return false; }
        return true;
      }
    });
    setContentView(w); w.loadUrl("file:///android_asset/index.html");
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode==FILE_CHOOSER && uploadMessage!=null) {
      Uri[] result=WebChromeClient.FileChooserParams.parseResult(resultCode,data);
      uploadMessage.onReceiveValue(result); uploadMessage=null;
    }
  }
}